﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Configuration;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
namespace tms
{
    public class Connect
    {
        public SqlCommand cmd = new SqlCommand();
        public SqlConnection con = new SqlConnection("Server=AJITHSHANBHOGUE\\SQLEXPRESS;Database=TEMPLERUN;Trusted_Connection=True");
        public Connect()
        {
            con.ConnectionString = "Server = AJITHSHANBHOGUE\\SQLEXPRESS; Database = TEMPLERUN; Trusted_Connection = True";
con.Open();
            cmd.Connection = con; }

    }
}