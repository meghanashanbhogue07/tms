﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace tms
{
    public partial class login_db : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;


        }

        protected void Button1_Click(object sender, EventArgs e)
        {
           /* if (TextBox1.Text == "" || TextBox2.Text == ""|| TextBox2.Text.Length < 6)
            {
                Label4.Visible = true;
                Label4.Text = "Please make sure that none of the textboxes are empty and the password has minimum of 6 characters!";

            }
           
            else
            {*/
                SqlConnection con = new SqlConnection("Server=AJITHSHANBHOGUE\\SQLEXPRESS;Database=TEMPLERUN;Trusted_Connection=True");
                SqlDataAdapter sda = new SqlDataAdapter("select count(*) from login_db where username='" + TextBox1.Text + "' and password='" + TextBox2.Text + "'", con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows[0][0].ToString() == "1")
                {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('LOGIN SUCCESSFULL');window.location='Home.aspx';", true);


                Response.Redirect("~/Home.aspx");
                }
                else if (dt.Rows[0][0].ToString() == "0")
                {
                    Response.Write("<script type=\"text/javascript\">alert('Incorrect Password!Please Try Again');</script>");
                }
                else
                {
                    Response.Write("<script type=\"text/javascript\">alert('login failed...Try again');</script>");
                }
            //}

        }

        protected void Button3_Click1(object sender, EventArgs e)
        {
            Response.Redirect("CreateUser.aspx");
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("ChangePassword.aspx");
        }

       

       
    }
}