﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

namespace tms
{
    public partial class ChangePassword : System.Web.UI.Page
    {
        

        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {
            
            
                SqlConnection con = new SqlConnection("Server=AJITHSHANBHOGUE\\SQLEXPRESS;Database=TEMPLERUN;Trusted_Connection=True");
                SqlDataAdapter sdr = new SqlDataAdapter("select * from login_db where username='" + txtusername.Text + "'", con);
                con.Open();
                DataTable dt = new DataTable();
                sdr.Fill(dt);
                if (dt.Rows.Count == 0)
                {
                    Label6.Text = "INVALID USERNAME";

                }
                else
                {
                     SqlDataAdapter sdr1 = new SqlDataAdapter("select * from login_db where username='" + txtusername.Text + "'", con);

                    DataTable dt1 = new DataTable();
                    sdr.Fill(dt1);
                    if (dt1.Rows.Count == 1)
                    {
                        var password = dt1.Rows[0]["password"].ToString();
                        if (txtpswd.Text != password)
                        {
                            Label6.Text = "PASSWORD MISMATCH";
                        }
                        else
                        {
                            SqlCommand cmd1 = new SqlCommand("update login_db set password='" + txtnpswd.Text + "'", con);
                            cmd1.ExecuteNonQuery();
                           // Label6.Text = "Password Updated Successfully....Please Login Again";
                            ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Password Updated Successfully....Please Login Again');window.location='login_db.aspx';", true);
                            
                           
                        }
                    }
                }
                con.Close();
            
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Response.Redirect("login_db.aspx");
        }

        protected void btncancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("Home.aspx");
        }
    }
}


        