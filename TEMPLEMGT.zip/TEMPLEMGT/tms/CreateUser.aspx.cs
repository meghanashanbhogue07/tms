﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace tms
{
    public partial class CreateUser : System.Web.UI.Page
    {
        Connect c = new Connect();

        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {   
            
                SqlConnection con = new SqlConnection("Server = AJITHSHANBHOGUE\\SQLEXPRESS; Database = TEMPLERUN; Trusted_Connection = True");
                SqlDataAdapter sdr = new SqlDataAdapter("select * from login_db  where username='" + TextBox2.Text + "'", con);
                con.Open();
                DataTable dt = new DataTable();
                sdr.Fill(dt);
                if (dt.Rows.Count >= 1)
                {
                    lblmsg.Text = "USERNAME ALREADY EXISTS";
                }
                else
                {
                    try
                    {
                        SqlCommand cmd = new SqlCommand("insert into login_db values(@username,@password,@email)");
                        cmd.Parameters.Clear();
                        cmd.Connection = con;
                        cmd.Parameters.AddWithValue("@username", TextBox2.Text.ToString());
                        cmd.Parameters.AddWithValue("@password", TextBox3.Text.ToString());
                        cmd.Parameters.AddWithValue("@email", Convert.ToString(TextBox1.Text));
                        cmd.ExecuteNonQuery();
                    lblmsg.Visible = true;

                    lblmsg.Text = "NEW USER ADDED!";
                    }
                    catch (Exception ex)
                    {
                    lblmsg.Visible = true;

                        lblmsg.Text = ex.ToString();

                    }
                    finally
                    {
                        con.Close();
                    }

                }


                con.Close();
            
        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("login_db.aspx");
        }
    }
}