﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace tms
{
    public partial class AddEmployee : System.Web.UI.Page
    {
        Connect c = new Connect();
        protected void Page_Load(object sender, EventArgs e)
        {
           
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            txtdob.Attributes.Add("placeholder", "yyyy/MM/dd");
            txtdoj.Attributes.Add("placeholder", "yyyy/MM/dd");
txtempname.Attributes.Add("placeholder", "Enter Employee Name");
            txtaddress.Attributes.Add("placeholder", "Enter Employee Address");
txtphno.Attributes.Add("placeholder", "Enter Employee Contact Number");


            Label12.Visible = false;
            if (!IsPostBack)
            {
                GenerateAutoID();
                txtempname.Focus();
            }

        }
        private void GenerateAutoID()
        {
            SqlCommand cmd = new SqlCommand("select count(*)from employee_db", c.con);
            int i = Convert.ToInt32(cmd.ExecuteScalar()) + 1;
            txtempid.Text = i.ToString();
        }

        protected void btnempclose_Click(object sender, EventArgs e)
        {

            ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('YOU ARE GOING BACK TO HOME!');window.location='Home.aspx';", true);


        }
       
        protected void btnempadd_Click(object sender, EventArgs e)
        {
           
           
                try
                {
                    c.cmd.CommandText = "insert into employee_db values(@empid,@empname,@gender,@dob,@age,@address,@phno,@desg,@basicsal,@doj)";
                    c.cmd.Parameters.AddWithValue("@empid", Convert.ToInt32(txtempid.Text));
                    c.cmd.Parameters.AddWithValue("@empname", txtempname.Text.ToString());

                    c.cmd.Parameters.AddWithValue("@gender", this.rdo.SelectedValue);
                    c.cmd.Parameters.AddWithValue("@dob", Convert.ToDateTime(txtdob.Text));
                    c.cmd.Parameters.AddWithValue("@age", txtempage.Text.ToString());
                    c.cmd.Parameters.AddWithValue("@address", txtaddress.Text.ToString());
                    c.cmd.Parameters.AddWithValue("@phno", txtphno.Text.ToString());
                    c.cmd.Parameters.AddWithValue("@desg", this.DropDownList1.SelectedItem.Text);
                    c.cmd.Parameters.AddWithValue("basicsal", this.txtsal.Text.ToString());
                    c.cmd.Parameters.AddWithValue("@doj", Convert.ToDateTime(txtdoj.Text));
                    c.cmd.ExecuteNonQuery();
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('EMPLOYEE RECORD ADDED SUCCESSFULLY');window.location='AddEmployee.aspx';", true);

                }
                catch (Exception ex)
                {
                    Label12.Visible = true;
                    Label12.Text = ex.Message.ToString();
                }
                finally
                {
                    c.con.Close();
                }
            

        }

        protected void btnempreset_Click(object sender, EventArgs e)
        {
           
            Response.Redirect("~/AddEmployee.aspx");

            NewId();
            txtempname.Text = "";
            //txtlname.Text = "";
            rdo.ClearSelection();
            txtdob.Text = "";
            txtempage.Text = "";
            txtaddress.Text = "";
            txtphno.Text = "";
            DropDownList1.ClearSelection();
            txtdoj.Text = "";
            txtsal.Text = "";
            


        }
        private void NewId()
        {
            SqlCommand command = new SqlCommand("select MAX(empid)+1 as id from employee_db", c.con);
            txtempid.Text = command.ExecuteScalar().ToString();
            c.con.Close();
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtsal.Text = Convert.ToString(DropDownList1.SelectedItem.Value);
            txtdoj.Focus();
        }

        protected void txtdob_TextChanged(object sender, EventArgs e)
        {
            DateTime now = DateTime.Now;
            DateTime dob = DateTime.Parse(txtdob.Text);
            int days = now.Subtract(dob).Days;
            int age = days / 365;
            txtempage.Text = age.ToString();

            txtaddress.Focus();
        }

        protected void rdo_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtdob.Focus();
        }

        protected void txtaddress_TextChanged(object sender, EventArgs e)
        {
            txtphno.Focus();
        }

        protected void txtdoj_TextChanged(object sender, EventArgs e)
        {
            btnempadd.Focus();
        }
    }
}