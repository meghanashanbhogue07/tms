﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace tms
{
    public partial class AddSupplier : System.Web.UI.Page
    {
        Connect c = new Connect();
        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;

            Label5.Visible = false;
            if (!IsPostBack)
            {
                GenerateAutoID();
            }

        }
        private void GenerateAutoID()
        {
            SqlCommand cmd = new SqlCommand("select count(*)from supplier_db", c.con);
            int i = Convert.ToInt32(cmd.ExecuteScalar()) + 1;
            txtid.Text = i.ToString();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            
            try
            {   c.cmd.CommandText = "insert into supplier_db values(@sid,@sname,@pno,@email)";
                c.cmd.Parameters.AddWithValue("@sid", Convert.ToInt32(txtid.Text));
                c.cmd.Parameters.AddWithValue("sname", txtname.Text);
                c.cmd.Parameters.AddWithValue("pno", txtpno.Text);
                c.cmd.Parameters.AddWithValue("email", txtemail.Text);
                c.cmd.ExecuteNonQuery();
                Response.Write("<script type=\"text/javascript\">alert('record added successfully');</script>");
            }
            catch(Exception ex)
            {
                Label5.Visible = true;
                Label5.Text = ex.ToString();

            }
            finally
            {
                c.con.Close();
                c.con.Dispose();

            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            NewId();
            txtname.Text = "";
            txtpno.Text = "";
            txtemail.Text = "";
                
        }
        private void NewId()
        {
            SqlCommand command = new SqlCommand("select MAX(sid)+1 as id from supplier_db", c.con);
            txtid.Text = command.ExecuteScalar().ToString();
            c.con.Close();
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Home.aspx");

        }

        protected void txtname_TextChanged(object sender, EventArgs e)
        {
            txtpno.Focus();
        }

        
    }
}