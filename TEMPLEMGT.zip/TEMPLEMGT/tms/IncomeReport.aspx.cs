﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace tms
{
    public partial class IncomeReport : System.Web.UI.Page
    {
        String strConnString = "Server=AJITHSHANBHOGUE\\SQLEXPRESS;Database=TEMPLERUN;Trusted_Connection=True";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                this.BindGrid();
                string constr = "Server=AJITHSHANBHOGUE\\SQLEXPRESS;Database=TEMPLERUN;Trusted_Connection=True";
                string query = "SELECT type,tamount from income";
                using (SqlConnection con = new SqlConnection(constr))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter(query, con))
                    {
                        using (DataTable dt1 = new DataTable())
                        {
                            sda.Fill(dt1);
                            GridView1.DataSource = dt1;
                            GridView1.DataBind();

                            string str = "select * from income;select sum(tamount) as totalamount from income";
                            SqlDataAdapter sdr = new SqlDataAdapter(str, con);
                            DataSet ds = new DataSet();
                            sdr.Fill(ds);
                            GridView1.DataSource = ds;
                            GridView1.Columns[1].FooterText = "TOTAL:";
                            GridView1.Columns[2].FooterText = ds.Tables[1].Rows[0]["totalamount"].ToString();
                            GridView1.DataBind();


                        }
                    }
                }
            }

        }
        protected void rowbound(object sender, GridViewRowEventArgs e)
        {

            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                Label lblserial = (Label)e.Row.FindControl("lblserial");
                lblserial.Text = ((GridView1.PageIndex * GridView1.PageSize) + e.Row.RowIndex + 1).ToString();


            }

        }
        protected void OnPaging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            this.BindGrid();
        }




        private void BindGrid()
        {

            string query = "SELECT * FROM income";
            using (SqlConnection con = new SqlConnection(strConnString))
            {
                using (SqlDataAdapter sda = new SqlDataAdapter(query, con))
                {
                    using (DataTable dt = new DataTable())
                    {
                        sda.Fill(dt);
                        GridView1.DataSource = dt;
                        GridView1.DataBind();
                    }
                }
            }
        }

        protected void btnsearch_Click1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(strConnString);
            SqlCommand cmd = new SqlCommand("SELECT  * FROM income where type like @type + '%'", con);
            cmd.Parameters.AddWithValue("@type", txtsearch.Text.Trim());
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();

            string str = "select * from income where type='" + txtsearch.Text + "' ;select sum(tamount) as totalamount from income where type='" + txtsearch.Text + "'";
            SqlDataAdapter sdr = new SqlDataAdapter(str, con);
            DataSet ds = new DataSet();
            sdr.Fill(ds);
            GridView1.DataSource = ds;
            GridView1.Columns[2].FooterText = ds.Tables[1].Rows[0]["totalamount"].ToString();
            GridView1.DataBind();

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("Home.aspx");
        }

       
        
    }
}