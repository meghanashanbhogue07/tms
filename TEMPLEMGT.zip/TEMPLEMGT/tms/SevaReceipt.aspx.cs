﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace tms
{
    public partial class SevaReceipt : System.Web.UI.Page
    {
        Connect c = new Connect();
        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;

            int day = System.DateTime.Now.Day;
            int month = System.DateTime.Now.Month;
            int year = System.DateTime.Now.Year;
            Label5.Text = day + "/" + month + "/" + year;

            Label15.Visible = false;
            if (!IsPostBack)
            {
                GenerateAutoID();
                SqlConnection con=new SqlConnection("Server=AJITHSHANBHOGUE\\SQLEXPRESS;Database=TEMPLERUN;Trusted_Connection=True"
            );
                SqlCommand cmd = new SqlCommand("select seva_name from seva_db", con);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                DropDownList1.DataSource = dt;
                DropDownList1.DataBind();
                DropDownList1.Items.Insert(0, "select seva");

                SqlCommand cmd1 = new SqlCommand("select item_name from stock", con);
                SqlDataAdapter sda1 = new SqlDataAdapter(cmd1);
                DataTable dt1 = new DataTable();
                sda1.Fill(dt1);
                DropDownList2.DataSource = dt1;
                DropDownList2.DataBind();
                DropDownList2.Items.Insert(0, "select item");


            }
            DropDownList1.Focus();
            









        }
        public void GenerateAutoID()
        {
            SqlCommand cmd = new SqlCommand("select count(*)from bookedseva", c.con);
            int i = Convert.ToInt32(cmd.ExecuteScalar()) + 1;
            TextBox10.Text = i.ToString();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {


            
            try
            {  string str = "Seva";
                    c.cmd.CommandText = "insert into bookedseva values(@rno,@date,@devoteename,@sevaname,@sevaqty,@itemname,@stockqty,@amount,@category)";
                    c.cmd.Parameters.AddWithValue("@rno", Convert.ToInt32(TextBox10.Text));

                    c.cmd.Parameters.AddWithValue("@date",Convert.ToDateTime( Label5.Text));
                    c.cmd.Parameters.AddWithValue("@devoteename", TextBox3.Text.ToString());

                    c.cmd.Parameters.AddWithValue("@sevaname", this.DropDownList1.SelectedItem.ToString());
                    c.cmd.Parameters.AddWithValue("@sevaqty", Convert.ToInt32(txtqty.Text));
                    c.cmd.Parameters.AddWithValue("@itemname", DropDownList2.SelectedItem.ToString());
                    c.cmd.Parameters.AddWithValue("@stockqty", Convert.ToInt32(TextBox6.Text));
                    c.cmd.Parameters.AddWithValue("@amount", (float)Convert.ToDouble(TextBox4.Text));
                    c.cmd.Parameters.AddWithValue("@category", str);

                    c.cmd.ExecuteNonQuery();
                    Response.Write("<script type=\"text/javascript\">alert('record added successfully');</script>");

                    string item_name = DropDownList2.SelectedItem.ToString();
                    c.cmd.CommandText = "select qty from stock where item_name='" + item_name + "'";
                    int i = Convert.ToInt32(c.cmd.ExecuteScalar());

                    int j = Convert.ToInt32(TextBox6.Text);
                    int qty = i - j;
                    string query = "update stock set qty=@qty where item_name=@item_name";

                    SqlCommand cmd = new SqlCommand(query);
                    cmd.Connection = c.con;
                    c.cmd.CommandText = query;
                    c.cmd.Parameters.AddWithValue("@item_name", item_name);
                    c.cmd.Parameters.AddWithValue("@qty", qty);
                    c.cmd.ExecuteNonQuery();

                    string query1 = "insert into income values(@type,@tamount)";
                    SqlCommand cmd1 = new SqlCommand(query1);
                    cmd.Connection = c.con;
                    c.cmd.CommandText = query1;
                    c.cmd.Parameters.AddWithValue("@type", str);
                    c.cmd.Parameters.AddWithValue("tamount", (float)Convert.ToDouble(TextBox4.Text));
                    c.cmd.ExecuteNonQuery();
                         

                
            }
            catch (Exception ex)
            {
                Label15.Visible = true;
                Label15.Text = ex.Message.ToString();
            }
            finally
            {
                c.con.Close();
            }
        }
    

            
        

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string dd = DropDownList1.SelectedValue.ToString();
            TextBox5.Text = dd;

            String str = "Server=AJITHSHANBHOGUE\\SQLEXPRESS;Database=TEMPLERUN;Trusted_Connection=True";
            String query = "select seva_price from seva_db where seva_name='"+TextBox5.Text+"'";
            SqlConnection con = new SqlConnection(str);
            SqlCommand cmd = new SqlCommand(query,con);
            //cmd.Parameters.AddWithValue("@seva_name", DropDownList1.SelectedItem.Value);
           // cmd.CommandType = CommandType.Text;
            //cmd.CommandText = str;
            //cmd.Connection = con;
            try
            {
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {
                    TextBox7.Text = sdr["seva_price"].ToString();

                }
               /* int price = Convert.ToInt32(TextBox7.Text);
                int qty = Convert.ToInt32(txtqty.Text);
                int total = price * qty;
                txttotal.Text = total.ToString();*/



            }
            catch (Exception ex)
            {
                throw ex;

            }
            finally
            {
                con.Close();
                con.Dispose();

            }
            txtqty.Focus();
        }

        protected void txtqty_TextChanged(object sender, EventArgs e)
        {
            int price = Convert.ToInt32(TextBox7.Text);
            int qty = Convert.ToInt32(txtqty.Text);
            int total = price * qty;
            txttotal.Text = total.ToString();

            DropDownList2.Focus();
        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string dd = DropDownList2.SelectedValue.ToString();
            //string  = dd;

            String str = "Server=AJITHSHANBHOGUE\\SQLEXPRESS;Database=TEMPLERUN;Trusted_Connection=True";
            String query = "select qty from stock where item_name='" + DropDownList2.SelectedValue.ToString() + "'";
            SqlConnection con = new SqlConnection(str);
            SqlCommand cmd = new SqlCommand(query, con);
            
            try
            {
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {
                    Label13.Text = sdr["qty"].ToString();

                }
                


            }
            catch (Exception ex)
            {
                throw ex;

            }
            finally
            {
                con.Close();
                con.Dispose();

            }
            TextBox6.Focus();
        }
        protected void TextBox6_TextChanged(object sender, EventArgs e)
        { int qty1 = Convert.ToInt32(TextBox6.Text);
            int qty2 = Convert.ToInt32(Label13.Text);
            if (qty1 > qty2)
            {
                Label15.Visible = true;
                Label15.Text = "NOT ENOUGH STOCK";
                TextBox6.Text = "";
                TextBox6.Focus();
            }
            else
            {
                TextBox8.Focus();
            }
            
            
        }

        protected void TextBox8_TextChanged(object sender, EventArgs e)
        {
            int qty = Convert.ToInt32(TextBox6.Text);
            float price =(float) Convert.ToDouble(TextBox8.Text);
            float total = (float)(qty * price);
            TextBox9.Text = total.ToString();
            float price1 = (float)Convert.ToDouble(txttotal.Text);
            float price2 = (float)Convert.ToDouble(TextBox9.Text);
            float finalprice = (float)(price1 + price2);
            TextBox4.Text = finalprice.ToString();

            TextBox3.Focus();
        }



        protected void TextBox9_TextChanged(object sender, EventArgs e)
        {
            /*float price1 = (float)Convert.ToDouble(txttotal.Text);
            float price2 = (float)Convert.ToDouble(TextBox9.Text);
            float finalprice = (float)(price1 + price2);
            TextBox4.Text = finalprice.ToString();*/
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/SevaReceipt.aspx");

        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Home.aspx");

        }

        protected void TextBox3_TextChanged(object sender, EventArgs e)
        {
            Button2.Focus();
        }
    }
}

             

   