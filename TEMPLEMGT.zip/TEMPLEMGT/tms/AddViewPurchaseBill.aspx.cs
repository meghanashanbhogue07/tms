﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace tms
{
    public partial class AddViewPurchaseBill : System.Web.UI.Page
    {
        Connect c = new Connect();
        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;

            TextBox11.Focus();
            TextBox11.Enabled = true;
            Button5.Visible = false;
            Panel2.Visible = false;
            Label6.Visible = false;
            int day = System.DateTime.Now.Day;
            int month = System.DateTime.Now.Month;
            int year = System.DateTime.Now.Year;
            Label1.Text = day + "/" + month + "/" + year;

            
        }
        private void GenerateAutoID()
        {
            SqlCommand cmd = new SqlCommand("select count(*)from purchasebill", c.con);
            int i = Convert.ToInt32(cmd.ExecuteScalar()) + 1;
            TextBox1.Text = i.ToString();
        }
        private void Functionfill()
        {
            Panel2.Visible = true;
            String str = "Server=AJITHSHANBHOGUE\\SQLEXPRESS;Database=TEMPLERUN;Trusted_Connection=True";
            String query = "select * from purchaseorder where pno='" + TextBox11.Text + "'";
            SqlConnection con = new SqlConnection(str);
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Connection = con;
            try
            {
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {
                    TextBox8.Text = sdr["pno"].ToString();
                    TextBox2.Text = sdr["pname"].ToString();
                    TextBox3.Text = sdr["qty"].ToString();
                    TextBox10.Text = sdr["supid"].ToString();
                    TextBox5.Text = sdr["supname"].ToString();
                    TextBox6.Text = sdr["suppno"].ToString();
                    TextBox7.Text = sdr["supemail"].ToString();

                }
            }
            catch (Exception ex)
            {
                Label6.Text = ex.ToString();
            }
            finally
            {
                con.Close();
                con.Dispose();
                TextBox9.Focus();
            }
        }

        protected void TextBox9_TextChanged(object sender, EventArgs e)
        {
            Panel2.Visible = true;
            this.Total();
            Button1.Focus();
        }
        private void Total()
        {
            float price = (float)Convert.ToDouble(TextBox3.Text);
            float qty = (float)Convert.ToDouble(TextBox9.Text);
            float total = (float)Convert.ToDouble(price * qty);
            TextBox4.Text = Convert.ToString(total);

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/AddViewPurchaseBill.aspx");
        }

        protected void TextBox11_TextChanged(object sender, EventArgs e)
        {
            c.cmd.CommandText = "select count(*) from purchasebill where pno='" + TextBox11.Text + "'";
            int i = Convert.ToInt32(c.cmd.ExecuteScalar());
            if (i > 0)
            {
                Label7.Visible = true;
                Label7.Text = "PURCHASE BILL FOR THIS ORDER HAS BEEN GENERATED CLICK THE BUTTON TO VIEW";
                Button5.Visible = true;
            }
            else if(i==0)
            {
                TextBox11.Enabled = false;
                Panel2.Visible = true;
                GenerateAutoID();
                Functionfill();
            }

            else
            {
               

                Label6.Visible = true;
                Label6.Text = "NO PURCHASE ORDER FOUND";

            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try

            {
                string str = "BILL";
                c.cmd.CommandText = "insert into purchasebill values(@pbno,@pno,@date,@pname,@price,@qty,@total,@sid,@sname,@sphno,@semail,@category)";
                c.cmd.Parameters.AddWithValue("@pbno", Convert.ToInt32(TextBox1.Text));
                c.cmd.Parameters.AddWithValue("@pno", Convert.ToInt32(TextBox8.Text));
                c.cmd.Parameters.AddWithValue("@date", Convert.ToDateTime(Label1.Text));
                c.cmd.Parameters.AddWithValue("@pname", TextBox2.Text);
                c.cmd.Parameters.AddWithValue("@price", (float)Convert.ToDouble(TextBox9.Text));
                c.cmd.Parameters.AddWithValue("@qty", Convert.ToInt32(TextBox3.Text));
                c.cmd.Parameters.AddWithValue("@total", (float)Convert.ToDouble(TextBox4.Text));
                c.cmd.Parameters.AddWithValue("@sid", Convert.ToInt32(TextBox10.Text));
                c.cmd.Parameters.AddWithValue("@sname", TextBox5.Text);
                c.cmd.Parameters.AddWithValue("sphno", TextBox6.Text);
                c.cmd.Parameters.AddWithValue("semail", TextBox7.Text);
                c.cmd.Parameters.AddWithValue("category", str);
                c.cmd.ExecuteNonQuery();

                Panel2.Visible = true;
                string query1 = "insert into expense values(@type,@tamount)";
                SqlCommand cmd1 = new SqlCommand(query1);
                cmd1.Connection = c.con;
                c.cmd.CommandText = query1;
                c.cmd.Parameters.AddWithValue("@type", str);
                c.cmd.Parameters.AddWithValue("@tamount", (float)Convert.ToDouble(TextBox4.Text));
                c.cmd.ExecuteNonQuery();
                //Response.Write("<script type=\"text/javascript\">alert('purchase bill saved successfully AND expense added successfully);</script>");
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('purchase bill saved successfully AND expense added successfully');", true);


            }
            catch (Exception ex)
            {
                Label6.Visible = true;
                Label6.Text = ex.Message.ToString();
            }
            finally
            {
                c.con.Close();
            }
        }
       
        protected void Button4_Click(object sender, EventArgs e)
        {
            string item_name = TextBox2.Text;
            c.cmd.CommandText = "select qty from stock where item_name='" + TextBox2.Text + "'";
            int i = Convert.ToInt32(c.cmd.ExecuteScalar());

            if (i > 0)
            {
                int j = Convert.ToInt32(TextBox3.Text);
                int qty = Convert.ToInt32(i + j);
                string query = "update stock set qty=@qty where item_name=@item_name";
                SqlCommand cmd = new SqlCommand(query);
                c.cmd.Connection = c.con;
                c.cmd.CommandText = query;
                c.cmd.Parameters.AddWithValue("@item_name", item_name);
                c.cmd.Parameters.AddWithValue("@qty", qty);
                c.cmd.ExecuteNonQuery();
                Response.Write("<script type=\"text/javascript\">alert('stock updated successfully');</script>");
                Panel2.Visible = true;
            }
            else
            {
                c.cmd.Connection = c.con;
                c.cmd.CommandText = "insert into stock values(@item_name,@qty)";
                c.cmd.Parameters.AddWithValue("@item_name", TextBox2.Text);
                c.cmd.Parameters.AddWithValue("@qty", Convert.ToInt32(TextBox3.Text));
                c.cmd.ExecuteNonQuery();
                Response.Write("<script type=\"text/javascript\">alert('stock inserted successfully');</script>");
                Panel2.Visible = true;
            }
            c.con.Close();

        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/ViewPurchaseBill.aspx");

        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Home.aspx");

        }

        protected void Button7_Click(object sender, EventArgs e)
        {
            string str = "BILL";

            string query1 = "insert into expense values(@type,@tamount)";
            SqlCommand cmd1 = new SqlCommand(query1);
            cmd1.Connection = c.con;
            c.cmd.CommandText = query1;
            c.cmd.Parameters.AddWithValue("@type", str);
            c.cmd.Parameters.AddWithValue("@tamount", (float)Convert.ToDouble(TextBox4.Text));
            c.cmd.ExecuteNonQuery();
            Response.Write("<script type=\"text/javascript\">alert('expense added successfully');</script>");

        }
    }

    }


    


