﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace tms
{
    public partial class PaySlip : System.Web.UI.Page
    { Connect c = new Connect();
        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;

            Label4.Visible = false;
            int day = System.DateTime.Now.Day;
            int month = System.DateTime.Now.Month;
            int year = System.DateTime.Now.Year;
            TextBox4.Text = day + "/" + month + "/" + year;
            ddlYear.Focus();
        
            if (!Page.IsPostBack)
            {
               for (int i = 2001; i <= System.DateTime.Now.Year+1; i++)
                {
                    ddlYear.Items.Add(i.ToString());
                    

                }
                for (int i = 1; i <= 12; i++)
                {
                    ddlMonth.Items.Add(i.ToString());
                }
                  FillDays();
                this.binddata();
                
            }
        }
        public void FillDays()
        {
            //ddlDay.Items.Clear();
             //var noofdays = DateTime.DaysInMonth(Convert.ToInt32(ddlYear.SelectedValue), Convert.ToInt32(ddlMonth.SelectedValue));
             for (int i = 1; i <= 31; i++)
            {
                ddlDay.Items.Add(i.ToString());
            }
        }
        protected void ddlYear_SelectedIndexChanged(object sender, EventArgs e)
        {
            FillDays();
            ddlMonth.Focus();
        }
        protected void ddlMonth_SelectedIndexChanged(object sender, EventArgs e)
        {
            FillDays();
            ddlDay.Focus();
        }
        private void binddata()
        {
            SqlConnection con = new SqlConnection("Server=AJITHSHANBHOGUE\\SQLEXPRESS;Database=TEMPLERUN;Trusted_Connection=True");
            SqlCommand cmd = new SqlCommand("select empname from employee_db", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            ddlemp.DataSource = dt;
            ddlemp.DataBind();
            ddlemp.Items.Insert(0, "select employee");
        }

        protected void ddlemp_SelectedIndexChanged(object sender, EventArgs e)
        {
            string name = ddlemp.SelectedItem.Text;
            SqlConnection con = new SqlConnection("Server=AJITHSHANBHOGUE\\SQLEXPRESS;Database=TEMPLERUN;Trusted_Connection=True");
            SqlCommand cmd = new SqlCommand("select basicsal from employee_db where empname='" + name + "'", con);
            cmd.Connection = con;
            try
            {
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {
                    TextBox2.Text = sdr["basicsal"].ToString();
              
                }


            }
            catch (Exception ex)
            {
                throw ex;

            }
            finally
            {
                con.Close();
                con.Dispose();

            }

            txtdayswrkd.Focus();
        }

        protected void txtdayswrkd_TextChanged(object sender, EventArgs e)
        {
            int sal = Convert.ToInt32(TextBox2.Text);
            int nodays = Convert.ToInt32(txtdayswrkd.Text);
            int pay = sal * nodays;
            TextBox3.Text = Convert.ToString(pay);
            Button1.Focus();
        }

       

        protected void Button1_Click1(object sender, EventArgs e)
        { string year = ddlYear.SelectedItem.ToString();
            string month = ddlMonth.SelectedItem.ToString();
            string day = ddlDay.SelectedItem.ToString();
            string date = String.Format("{0}/{1}/{2}", year, month, day);

            try
            {
                string str = "Salary";
                c.cmd.CommandText = "insert into salary values(@date,@empname,@count,@basicpay,@totalpay,@paydate,@category)";

                c.cmd.Parameters.AddWithValue("@date", Convert.ToDateTime(date.ToString()));
                c.cmd.Parameters.AddWithValue("@empname", ddlemp.SelectedItem.ToString());

                c.cmd.Parameters.AddWithValue("@count", this.txtdayswrkd.Text);
                c.cmd.Parameters.AddWithValue("@basicpay", (float)Convert.ToDouble(TextBox2.Text.ToString()));
                c.cmd.Parameters.AddWithValue("@totalpay", (float)Convert.ToDouble(TextBox3.Text.ToString()));
                c.cmd.Parameters.AddWithValue("@paydate", Convert.ToDateTime(TextBox4.Text.ToString()));
                c.cmd.Parameters.AddWithValue("@category",str);

                c.cmd.ExecuteNonQuery();
                Response.Write("<script type=\"text/javascript\">alert('payslip generated successfully');</script>");

                string query1 = "insert into expense values(@type,@tamount)";
                SqlCommand cmd1 = new SqlCommand(query1);
                cmd1.Connection = c.con;
                c.cmd.CommandText = query1;
                c.cmd.Parameters.AddWithValue("@type", str);
                c.cmd.Parameters.AddWithValue("@tamount", (float)Convert.ToDouble(TextBox3.Text));
                c.cmd.ExecuteNonQuery();
            }
            catch(Exception ex)
            {
                Label4.Visible = true;
                Label4.Text = ex.ToString();

            }
            finally
            {
                c.con.Close();
            }
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/PaySlip.aspx");
            ddlYear.ClearSelection();
            ddlMonth.ClearSelection();
            ddlDay.ClearSelection();
            ddlemp.ClearSelection();
            txtdayswrkd.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
       
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("Home.aspx");

        }

        protected void ddlDay_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlemp.Focus();
        }
    }   
    }
