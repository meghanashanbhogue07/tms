﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace tms
{
    public partial class ViewDeleteUpdateSupplier : System.Web.UI.Page
    {
        String strConnString = "Server=AJITHSHANBHOGUE\\SQLEXPRESS;Database=TEMPLERUN;Trusted_Connection=True";
        
        protected void Page_Load(object sender, EventArgs e)
        {
            Label1.Visible = false;
            if (!this.IsPostBack)
            {
                this.BindGrid();
                this.GetData();
            }

        }
        private void GetData()
        {
            SqlConnection con = new SqlConnection(strConnString);
            SqlCommand cmd = new SqlCommand("SELECT  * FROM supplier_db", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }

        private void BindGrid()
        {

            string query = "SELECT * FROM supplier_db";
            using (SqlConnection con = new SqlConnection(strConnString))
            {
                using (SqlDataAdapter sda = new SqlDataAdapter(query, con))
                {
                    using (DataTable dt = new DataTable())
                    {
                        sda.Fill(dt);
                        GridView1.DataSource = dt;
                        GridView1.DataBind();
                    }
                }
            }
        }
        protected void OnRowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            this.BindGrid();
        }

        protected void OnRowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow row = GridView1.Rows[e.RowIndex];
            int sid= Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Values[0]);
            string sname = (row.FindControl("txtsname") as TextBox).Text;
            string phno = (row.FindControl("txtpno") as TextBox).Text;
            string email = (row.FindControl("txtemail") as TextBox).Text;

            string query = "UPDATE supplier_db SET sname=@sname, phno=@phno,email=@email WHERE sid=@sid";
            string constr = "Server=AJITHSHANBHOGUE\\SQLEXPRESS;Database=TEMPLERUN;Trusted_Connection=True";
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand(query))
                {
                    cmd.Parameters.AddWithValue("@sid", sid);
                   cmd.Parameters.AddWithValue("@sname", sname);
                    cmd.Parameters.AddWithValue("@phno", phno);
                    cmd.Parameters.AddWithValue("@email", email);
                    cmd.Connection = con;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
            GridView1.EditIndex = -1;
            this.BindGrid();
        }

        protected void OnRowCancelingEdit(object sender, EventArgs e)
        {
            GridView1.EditIndex = -1;
            this.BindGrid();
        }

        protected void OnRowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int sid = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Values[0]);
            string query = "DELETE FROM supplier_db WHERE sid=@sid";
            string constr = "Server=AJITHSHANBHOGUE\\SQLEXPRESS;Database=TEMPLERUN;Trusted_Connection=True";
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand(query))
                {
                    cmd.Parameters.AddWithValue("@sid", sid);
                    cmd.Connection = con;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }

            this.BindGrid();
        }
        protected void OnPaging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            this.BindGrid();
        }

       public DataSet Bind()
        {
            SqlConnection con = new SqlConnection(strConnString);
            SqlCommand cmd = new SqlCommand("select* from supplier_db where sname like'" + txtsearch.Text + "%'");
            con.Open();
            cmd.Connection = con;
            SqlDataAdapter sdr = new SqlDataAdapter(cmd);
            
            DataSet ds = new DataSet();
            sdr.Fill(ds);
            if(!object.Equals(ds,null))
            {
                if(ds.Tables[0].Rows.Count>0)
                {
                    GridView1.DataSource = ds.Tables[0];
                    GridView1.DataBind();
                }
            }
            con.Close();
            return ds;
            
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            if (txtsearch.Text == "")
            {
                Label1.Text = "ENTER NAME TO SEARCH";
            }
            else
            {
                DataSet ds = Bind();
                if (!object.Equals(ds, null))
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        GridView1.Visible = true;
                        txtsearch.Text = "";
                        Label1.Visible = false;
                    }

                    else
                    {
                        GridView1.Visible = false;
                        Label1.Visible = true;
                        Label1.Text = "NOT AVAILABLE IN THE RECORD";

                    }
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Home.aspx");
        }
        protected void rowbound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                Label lblserial = (Label)e.Row.FindControl("lblserial");
                lblserial.Text = ((GridView1.PageIndex * GridView1.PageSize) + e.Row.RowIndex + 1).ToString();

            }
        }
    }
}