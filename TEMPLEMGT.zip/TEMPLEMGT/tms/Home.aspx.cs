﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
namespace tms
{
    public partial class Home : System.Web.UI.Page
    {
        Connect c = new Connect();
        protected void Page_Load(object sender, EventArgs e)
        {
           

            String strConnString = "Server=AJITHSHANBHOGUE\\SQLEXPRESS;Database=TEMPLERUN;Trusted_Connection=True";
            // GenerateMaxOrder();
            if (!IsPostBack)
            {
                DataTable dt = this.BindMenuData(0);
                DynamicMenuControlPopulation(dt, 0, null);
                string query = "SELECT * FROM stock";
                using (SqlConnection con = new SqlConnection(strConnString))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter(query, con))
                    {
                        using (DataTable dt1 = new DataTable())
                        {
                            sda.Fill(dt1);
                            GridView1.DataSource = dt1;
                            GridView1.DataBind();
                        }
                    }
                }
                
            }
        }
        
        protected DataTable BindMenuData(int parentmenuId)
        {
            //declaration of variable used  
            DataSet ds = new DataSet();
            DataTable dt;
            DataRow dr;
            DataColumn menu;
            DataColumn pMenu;
            DataColumn title;
            DataColumn description;
            DataColumn URL;

            //create an object of datatable  
            dt = new DataTable();

            //creating column of datatable with datatype  
            menu = new DataColumn("MenuId", Type.GetType("System.Int32"));
            pMenu = new DataColumn("ParentId", Type.GetType("System.Int32"));
            title = new DataColumn("Title", Type.GetType("System.String"));
            description = new DataColumn("Description", Type.GetType("System.String"));
            URL = new DataColumn("URL", Type.GetType("System.String"));

            //bind data table columns in datatable  
            dt.Columns.Add(menu);//1st column  
            dt.Columns.Add(pMenu);//2nd column  
            dt.Columns.Add(title);//3rd column  
            dt.Columns.Add(description);//4th column  
            dt.Columns.Add(URL);//5th column  

            //creating data row and assiging the value to columns of datatable  

            //PARENT row of data table  
            dr = dt.NewRow();
            dr["MenuId"] = 1;
            dr["ParentId"] = 0;
            dr["Title"] = "Manage Seva";
            dr["Description"] = "Manage Seva";
            dt.Rows.Add(dr);


            dr = dt.NewRow();
            dr["MenuId"] = 2;
            dr["ParentId"] = 0;
            dr["Title"] = "Manage Employee";
            dr["Description"] = "Manage Employee";
            dt.Rows.Add(dr);


            dr = dt.NewRow();
            dr["MenuId"] = 3;
            dr["ParentId"] = 0;
            dr["Title"] = "Manage Supplier";
            dr["Description"] = "Manage Supplier";
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["MenuId"] = 4;
            dr["ParentId"] = 0;
            dr["Title"] = "Generate Receipt";
            dr["Description"] = "Generate Receipt";
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["MenuId"] = 5;
            dr["ParentId"] = 0;
            dr["Title"] = "Purchase Order";
            dr["Description"] = "Manage Supplier";
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["MenuId"] = 6;
            dr["ParentId"] = 0;
            dr["Title"] = "Purchase Bill";
            dr["Description"] = "Purchase Bill";
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["MenuId"] = 7;
            dr["ParentId"] = 0;
            dr["Title"] = "Reports";
            dr["Description"] = "Reports";

            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["MenuId"] = 8;
            dr["ParentId"] = 0;
            dr["Title"] = "Change Password";
            dr["Description"] = "Change Password";
            dr["URL"] = "~/ChangePassword.aspx";
            dt.Rows.Add(dr);

            //CHILD ROWS

            dr = dt.NewRow();
            dr["MenuId"] = 9;
            dr["ParentId"] = 1;
            dr["Title"] = "Add";
            dr["URL"] = "~/AddSeva.aspx";
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["MenuId"] = 10;
            dr["ParentId"] = 1;
            dr["Title"] = "View/Update";
            dr["URL"] = "~/ViewEditSeva.aspx";
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["MenuId"] = 11;
            dr["ParentId"] = 2;
            dr["Title"] = "Add";
            dr["URL"] = "~/AddEmployee.aspx";
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["MenuId"] = 12;
            dr["ParentId"] = 2;
            dr["Title"] = "View/Delete/Update";
            dr["URL"] = "~/ViewDeleteEmployee.aspx";
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["MenuId"] = 13;
            dr["ParentId"] = 2;
            dr["Title"] = "Generate Payslip";
            dr["URL"] = "~/PaySlip.aspx";
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["MenuId"] = 14;
            dr["ParentId"] = 3;
            dr["Title"] = "Add";
            dr["URL"] = "~/AddSupplier.aspx";
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["MenuId"] = 15;
            dr["ParentId"] = 3;
            dr["Title"] = "View/Update";
            dr["URL"] = "~/ViewDeleteUpdateSupplier.aspx";
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["MenuId"] = 16;
            dr["ParentId"] = 4;
            dr["Title"] = "Seva Receipt";
            dr["URL"] = "~/SevaReceipt.aspx";
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["MenuId"] = 17;
            dr["ParentId"] = 4;
            dr["Title"] = "Donation Receipt";
            dr["URL"] = "~/DonationReceipt.aspx";
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["MenuId"] = 18;
            dr["ParentId"] = 5;
            dr["Title"] = "Create New PurchaseOrder";
            dr["URL"] = "~/CreateViewPurchaseOrder.aspx";
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["MenuId"] = 19;
            dr["ParentId"] = 5;
            dr["Title"] = "View Purchase Orders";
            dr["URL"] = "~/ViewPurchaseOrder.aspx";
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["MenuId"] = 20;
            dr["ParentId"] = 6;
            dr["Title"] = "Add Purchase Bill";
            dr["URL"] = "~/AddViewPurchaseBill.aspx";
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["MenuId"] = 21;
            dr["ParentId"] = 6;
            dr["Title"] = "View Purchase Bill";
            dr["URL"] = "~/ViewPurchaseBill.aspx";
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["MenuId"] = 22;
            dr["ParentId"] = 7;
            dr["Title"] = "IncomeReport";
            dr["URL"] = "~/IncomeReport.aspx";
            dt.Rows.Add(dr); dr = dt.NewRow();

            dr["MenuId"] = 23;
            dr["ParentId"] = 7;
            dr["Title"] = "Expense Report";
            dr["URL"] = "~/ExpenseReport.aspx";
            dt.Rows.Add(dr); dr = dt.NewRow();

            dr["MenuId"] = 24;
            dr["ParentId"] = 7;
            dr["Title"] = "Booked Seva Report";
            dr["URL"] = "~/BookedSevaReport.aspx";
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["MenuId"] = 25;
            dr["ParentId"] = 7;
            dr["Title"] = "Donation Report";
            dr["URL"] = "~/DonationReport.aspx";
            dt.Rows.Add(dr); dr = dt.NewRow();

            ds.Tables.Add(dt);
            var dv = ds.Tables[0].DefaultView;
            dv.RowFilter = "ParentId='" + parentmenuId + "'";
            DataSet ds1 = new DataSet();
            var newdt = dv.ToTable();
            return newdt;
        }

        /// <summary>  
        /// This is a recursive function to fetchout the data to create a menu from data table  
        /// </summary>  
        /// <param name="dt">datatable</param>  
        /// <param name="parentMenuId">parent menu Id of integer type</param>  
        /// <param name="parentMenuItem"> Menu Item control</param>  ///
        protected void DynamicMenuControlPopulation(DataTable dt, int parentMenuId, MenuItem parentMenuItem)
        {
            string currentPage = Path.GetFileName(Request.Url.AbsolutePath);
            foreach (DataRow row in dt.Rows)
            {
                MenuItem menuItem = new MenuItem
                {
                    Value = row["MenuId"].ToString(),
                    Text = row["Title"].ToString(),
                    NavigateUrl = row["URL"].ToString(),
                    Selected = row["URL"].ToString().EndsWith(currentPage, StringComparison.CurrentCultureIgnoreCase)
                };
                if (parentMenuId == 0)
                {
                    Menu1.Items.Add(menuItem);
                    DataTable dtChild = this.BindMenuData(int.Parse(menuItem.Value));
                    DynamicMenuControlPopulation(dtChild, int.Parse(menuItem.Value), menuItem);
                }
                else
                {

                    parentMenuItem.ChildItems.Add(menuItem);
                    DataTable dtChild = this.BindMenuData(int.Parse(menuItem.Value));
                    DynamicMenuControlPopulation(dtChild, int.Parse(menuItem.Value), menuItem);

                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("~/login_db.aspx");

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        
    }
}

