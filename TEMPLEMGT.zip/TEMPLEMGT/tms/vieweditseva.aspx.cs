﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace tms
{
    public partial class vieweditseva : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                this.BindGrid();
            }
        }
        private void BindGrid()
        {
            string constr = "Server=AJITHSHANBHOGUE\\SQLEXPRESS;Database=TEMPLERUN;Trusted_Connection=True";
            string query = "SELECT * FROM seva_db";
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlDataAdapter sda = new SqlDataAdapter(query, con))
                {
                    using (DataTable dt = new DataTable())
                    {
                        sda.Fill(dt);
                        GridView1.DataSource = dt;
                        GridView1.DataBind();
                    }
                }
            }
        }
        protected void OnRowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            this.BindGrid();
        }

        protected void OnRowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow row = GridView1.Rows[e.RowIndex];
            int seva_code = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Values[0]);
            string seva_name = (row.FindControl("txtsevaname") as TextBox).Text;
            string seva_price = (row.FindControl("txtsevaprice") as TextBox).Text;

            string query = "UPDATE seva_db SET seva_name=@seva_name, seva_price=@seva_price WHERE seva_code=@seva_code";
            string constr = "Server=AJITHSHANBHOGUE\\SQLEXPRESS;Database=TEMPLERUN;Trusted_Connection=True";
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand(query))
                {
                    cmd.Parameters.AddWithValue("@seva_code", seva_code);
                    cmd.Parameters.AddWithValue("@seva_name", seva_name);
                    cmd.Parameters.AddWithValue("@seva_price", seva_price);
                    cmd.Connection = con;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
            GridView1.EditIndex = -1;
            this.BindGrid();
        }
        protected void OnRowCancelingEdit(object sender, EventArgs e)
        {
            GridView1.EditIndex = -1;
            this.BindGrid();
        }
        protected void OnRowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int seva_code = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Values[0]);
            string query = "DELETE FROM seva_db WHERE seva_code=@seva_code";
            string constr = "Server=AJITHSHANBHOGUE\\SQLEXPRESS;Database=TEMPLERUN;Trusted_Connection=True";
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand(query))
                {
                    cmd.Parameters.AddWithValue("@seva_code", seva_code);
                    cmd.Connection = con;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }

            this.BindGrid();
        }
        
        protected void OnPaging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            this.BindGrid();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Home.aspx");
        }
    }
}










        