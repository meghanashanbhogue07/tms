﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace tms
{
    public partial class AddSeva : System.Web.UI.Page
    {
        Connect c = new Connect();
        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;

            if (!IsPostBack)
            {
                GenerateAutoID();
            }
            txtsevaname.Focus();

        }

        private void GenerateAutoID()
        { SqlCommand cmd = new SqlCommand("select count(*)from seva_db", c.con);
            int i = Convert.ToInt32(cmd.ExecuteScalar()) + 1;
            txtcode.Text = i.ToString();
        }

        protected void Btnsevaadd_Click(object sender, EventArgs e)
        {
            
            try
            {
                c.cmd.CommandText="insert into seva_db values(@seva_code,@seva_name,@seva_price)";
                c.cmd.Parameters.AddWithValue("@seva_code", Convert.ToInt32(txtcode.Text));
                c.cmd.Parameters.AddWithValue("@seva_name", txtsevaname.Text.ToString());
                c.cmd.Parameters.AddWithValue("@seva_price", txtprice.Text.ToString());
                c.cmd.ExecuteNonQuery();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('SEVA ADDED SUCCESSFULLY');window.location='AddSeva.aspx';", true);


            }
            catch (Exception ex)
            {
                Label5.Visible = true;
                Label5.Text = ex.Message.ToString();
            }
            finally
            {
                c.con.Close();
            }
        }

        protected void btnsevareset_Click(object sender, EventArgs e)
        {
            NewId();
            txtsevaname.Text = "";
            txtprice.Text = "";
            txtsevaname.Focus();
        }
        private void NewId()
        {
            SqlCommand command = new SqlCommand("select MAX(seva_code)+1 as code from seva_db", c.con);
            txtcode.Text = command.ExecuteScalar().ToString();
            c.con.Close();
        }
        

        protected void brnsevaexit_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Home.aspx");

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/vieweditseva.aspx");
        }

        protected void txtsevaname_TextChanged(object sender, EventArgs e)
        {
            txtprice.Focus();
        }
    }
}