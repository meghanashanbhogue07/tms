﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace tms
{
    public partial class UpdateEmployee : System.Web.UI.Page
    {
        String strConnString = "Server=AJITHSHANBHOGUE\\SQLEXPRESS;Database=TEMPLERUN;Trusted_Connection=True";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                this.BindGrid();
                this.GetData();
            }
        }
        private void GetData()
        {
            SqlConnection con = new SqlConnection(strConnString);
            SqlCommand cmd = new SqlCommand("SELECT  * FROM employee_db", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
           
        }

        private void BindGrid()
        {
           
            string query = "SELECT * FROM employee_db";
            using (SqlConnection con = new SqlConnection(strConnString))
            {
                using (SqlDataAdapter sda = new SqlDataAdapter(query, con))
                {
                    using (DataTable dt = new DataTable())
                    {
                        sda.Fill(dt);
                        GridView1.DataSource = dt;
                        GridView1.DataBind();
                    }
                }
            }
        }
        
        protected void OnRowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            this.BindGrid();
        }
        
        protected void OnRowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow row = GridView1.Rows[e.RowIndex];
            int empid = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Values[0]);
            string empname = (row.FindControl("txtfname") as TextBox).Text;
            string  gender= (row.FindControl("txtgen") as TextBox).Text;
            string dob = (row.FindControl("txtdob") as TextBox).Text;
            string age = (row.FindControl("txtage") as TextBox).Text;
            string phno = (row.FindControl("txtphno") as TextBox).Text;
            string desg = (row.FindControl("txtdesg") as TextBox).Text;
            string basicsal = (row.FindControl("txtbasicsal") as TextBox).Text;
            string doj = (row.FindControl("txtdoj") as TextBox).Text;
           

            string query = "UPDATE employee_db SET empname=@empname, gender=@gender,dob=@dob,age=@age,phno=@phno,desg=@desg,basicsal=@basicsal,doj=@doj  WHERE empid=@empid";
            string constr = "Server=AJITHSHANBHOGUE\\SQLEXPRESS;Database=TEMPLERUN;Trusted_Connection=True";
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand(query))
                {
                    cmd.Parameters.AddWithValue("@empid", empid);
                    cmd.Parameters.AddWithValue("@empname", empname);
                    cmd.Parameters.AddWithValue("@gender", gender);
                    cmd.Parameters.AddWithValue("@dob", dob);
                    cmd.Parameters.AddWithValue("@age", age);
                    cmd.Parameters.AddWithValue("@phno", phno);
                    cmd.Parameters.AddWithValue("@desg", desg);
                    cmd.Parameters.AddWithValue("@basicsal", basicsal);
                    cmd.Parameters.AddWithValue("@doj", doj);


                    cmd.Connection = con;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
            GridView1.EditIndex = -1;
            this.BindGrid();
        }
        protected void OnRowCancelingEdit(object sender, EventArgs e)
        {
            GridView1.EditIndex = -1;
            this.BindGrid();
        }



        protected void OnRowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int empid = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Values[0]);
            string query = "DELETE FROM employee_db WHERE empid=@empid";
            string constr = "Server=AJITHSHANBHOGUE\\SQLEXPRESS;Database=TEMPLERUN;Trusted_Connection=True";
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand(query))
                {
                    cmd.Parameters.AddWithValue("@empid", empid);
                    cmd.Connection = con;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }

            this.BindGrid();
        }

        protected void OnPaging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            this.BindGrid();
        }

       
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(strConnString);
            SqlCommand cmd = new SqlCommand("SELECT  * FROM employee_db  where empname like @empname + '%'", con);
            cmd.Parameters.AddWithValue("@empname", txtsearch.Text.Trim());
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            Response.Redirect("~/Home.aspx");
        }
        protected void rowbound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                Label lblserial = (Label)e.Row.FindControl("lblserial");
                lblserial.Text = ((GridView1.PageIndex * GridView1.PageSize) + e.Row.RowIndex + 1).ToString();
               
            }
            
        }
    }
}

    
