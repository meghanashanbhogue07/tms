﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace tms
{
    public partial class DonationReceipt : System.Web.UI.Page
    { Connect c = new Connect();
        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;

            int day = System.DateTime.Now.Day;
            int month = System.DateTime.Now.Month;
            int year = System.DateTime.Now.Year;
            txtdate.Text = day + "/" + month + "/" + year;

            SqlCommand cmd = new SqlCommand("select count(*)from donation", c.con);
            int i = Convert.ToInt32(cmd.ExecuteScalar()) + 1;
            TextBox1.Text = i.ToString();

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

                try
                {
                    string str = "Donation";
                    c.cmd.CommandText = "insert into donation values(@dno,@date,@name,@phno,@purpose,@amount,@category)";

                    c.cmd.Parameters.AddWithValue("@dno", Convert.ToInt32(TextBox1.Text));

                    c.cmd.Parameters.AddWithValue("@date", Convert.ToDateTime(txtdate.Text));
                    c.cmd.Parameters.AddWithValue("@name", txtname.Text.ToString());

                    c.cmd.Parameters.AddWithValue("@phno", txtphno.Text.ToString());
                    c.cmd.Parameters.AddWithValue("@purpose", txtps.Text);
                    c.cmd.Parameters.AddWithValue("@amount", (float)(Convert.ToDouble(txtamt.Text)));

                    c.cmd.Parameters.AddWithValue("@category", str);

                    c.cmd.ExecuteNonQuery();
                    Response.Write("<script type=\"text/javascript\">alert('record added successfully');</script>");

                    string query1 = "insert into income values(@type,@tamount)";
                    SqlCommand cmd1 = new SqlCommand(query1);
                    cmd1.Connection = c.con;
                    c.cmd.CommandText = query1;
                    c.cmd.Parameters.AddWithValue("@type", str);
                    c.cmd.Parameters.AddWithValue("@tamount", (float)Convert.ToDouble(txtamt.Text));
                    c.cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    Label1.Visible = true;
                    Label1.Text = ex.ToString();
                }
                finally
                {

                }
            
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/DonationReceipt.aspx");

        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Home.aspx");

        }

        protected void txtname_TextChanged(object sender, EventArgs e)
        {
            txtphno.Focus();
        }

        protected void txtphno_TextChanged(object sender, EventArgs e)
        {
            txtps.Focus();
        }

        protected void txtps_TextChanged(object sender, EventArgs e)
        {
            txtamt.Focus();
        }

        protected void txtamt_TextChanged(object sender, EventArgs e)
        {
            Button1.Focus();
        }
    }
}