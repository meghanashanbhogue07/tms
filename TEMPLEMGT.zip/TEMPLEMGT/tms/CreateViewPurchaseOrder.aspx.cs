﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace tms
{
    public partial class CreatePurchaseOrder : System.Web.UI.Page
    { Connect c = new Connect();
        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;


            int day = System.DateTime.Now.Day;
            int month = System.DateTime.Now.Month;
            int year = System.DateTime.Now.Year;
            Label1.Text = day + "/" + month + "/" + year;

            if (!IsPostBack)
            {
                SqlConnection con = new SqlConnection("Server=AJITHSHANBHOGUE\\SQLEXPRESS;Database=TEMPLERUN;Trusted_Connection=True"
                            );
                SqlCommand cmd = new SqlCommand("select sname from supplier_db", con);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                ddlsup.DataSource = dt;
                ddlsup.DataBind();
                ddlsup.Items.Insert(0, new ListItem("select"));
                BindGrid();
             GenerateAutoID();
            }
        }
        private void GenerateAutoID()
        {
            SqlCommand cmd = new SqlCommand("select count(*)from purchaseorder", c.con);
            int i = Convert.ToInt32(cmd.ExecuteScalar()) + 1;
            TextBox4.Text = i.ToString();
        }

        protected void ddlsup_SelectedIndexChanged(object sender, EventArgs e)
        {
            String str = "Server=AJITHSHANBHOGUE\\SQLEXPRESS;Database=TEMPLERUN;Trusted_Connection=True";
            String query = "select sid,phno,email from supplier_db where sname='" + ddlsup.SelectedValue.ToString() + "'";
            SqlConnection con = new SqlConnection(str);
            SqlCommand cmd = new SqlCommand(query, con);
            try
            {
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {
                    TextBox1.Text = sdr["sid"].ToString();
                    TextBox2.Text = sdr["phno"].ToString();
                    TextBox3.Text = sdr["email"].ToString();

                }


            }
            catch (Exception ex)
            {
                throw ex;

            }
            finally
            {
                con.Close();
                con.Dispose();

            }
            txtprodname.Focus();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if(txtprodname.Text==""||txtqty.Text==""||ddlsup.SelectedIndex==0)
            {
                Label7.Text = "NONE OF THE FIELDS SHOULD BE EMPTY";
            }
            try
            {
                c.cmd.CommandText = "insert into purchaseorder values(@pno,@date,@pname,@qty,@supid,@supname,@suppno,@supemail)";
                c.cmd.Parameters.AddWithValue("@pno", Convert.ToInt32(TextBox4.Text));
                c.cmd.Parameters.AddWithValue("@date", Convert.ToDateTime(Label1.Text));
                c.cmd.Parameters.AddWithValue("@pname", txtprodname.Text.ToString());
                c.cmd.Parameters.AddWithValue("@qty", Convert.ToInt32(txtqty.Text));
                c.cmd.Parameters.AddWithValue("@supid", Convert.ToInt32(TextBox1.Text));
                c.cmd.Parameters.AddWithValue("@supname", ddlsup.SelectedValue.ToString());
                c.cmd.Parameters.AddWithValue("@suppno", TextBox2.Text);
                c.cmd.Parameters.AddWithValue("@supemail", TextBox3.Text);
                c.cmd.ExecuteNonQuery();
                Response.Write("<script type=\"text/javascript\">alert('purchase order created successfully');</script>");

            }
            catch (Exception ex)
            {
                Label7.Visible = true;
                Label7.Text = ex.Message.ToString();
            }
            finally
            {
                c.con.Close();
                Button5.Focus();

            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            NewId();
            ddlsup.ClearSelection();
            txtprodname.Text = "";
            txtqty.Text = "";

        }
        private void NewId()
        {
            SqlCommand command = new SqlCommand("select MAX(pno)+1 as pno from purchaseorder", c.con);
            TextBox4.Text = command.ExecuteScalar().ToString();
            c.con.Close();
        }
        private void BindGrid()
        {
            string constr = "Server=AJITHSHANBHOGUE\\SQLEXPRESS;Database=TEMPLERUN;Trusted_Connection=True";
            string query = "SELECT * FROM purchaseorder";
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlDataAdapter sda = new SqlDataAdapter(query, con))
                {
                    using (DataTable dt = new DataTable())
                    {
                        sda.Fill(dt);
                        GridView1.DataSource = dt;
                        GridView1.DataBind();
                    }
                }
            }
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Home.aspx");

        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/CreateViewPurchaseOrder.aspx");

        }

        protected void txtprodname_TextChanged(object sender, EventArgs e)
        {
            txtqty.Focus();
        }

        protected void txtqty_TextChanged(object sender, EventArgs e)
        {
            Button1.Focus();
        }
        protected void rowbound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                Label lblserial = (Label)e.Row.FindControl("lblserial");
                lblserial.Text = ((GridView1.PageIndex * GridView1.PageSize) + e.Row.RowIndex + 1).ToString();

            }
        }
    }
}